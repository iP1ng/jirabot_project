"""
Логирование
"""


from logs.logs import Logs